create table users (
    id int primary key,
    name varchar
);